<?php

namespace App\Services;

use App\Models\Dish;
use App\Models\ParameterWeight;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class SwipeService
{
    /**
     *
     * @param  'like'|'dislike'  $decision
     */
    public function swipe(User $user, Dish $dish, string $decision): void
    {
        $decision = strtolower($decision);
        if (!in_array($decision, ['like', 'dislike'], true)) {
            throw new InvalidArgumentException('decision must be "like" or "dislike"');
        }

        DB::transaction(function () use ($user, $dish, $decision) {
            $user->likedDishes()->syncWithoutDetaching([$dish->id]);

            $parameterIds = $dish->parameters()->pluck('parameters.id');

            foreach ($parameterIds as $pid) {
                $pw = ParameterWeight::firstOrNew([
                    'user_id'      => $user->id,
                    'parameter_id' => $pid,
                ]);

                $current = (float) ($pw->weight ?? 0.0);
                $delta   = $decision === 'like' ? 1.0 : -1.0;

                $pw->weight = $this->clamp($current + $delta, 0.0, 20.0);
                $pw->save();
            }
        });
    }

    public function getUnswipedDishes(User $user, int $limit): Collection
    {
        $swipedDishIds = $user->likedDishes()->pluck('dishes.id');

        $available = Dish::whereNotIn('id', $swipedDishIds)->count();
        $limit = max(0, min($limit, $available));

        return Dish::with('parameters')
            ->whereNotIn('id', $swipedDishIds)
            ->inRandomOrder()
            ->take($limit)
            ->get();
    }

    private function clamp(float $v, float $min, float $max): float
    {
        return max($min, min($max, $v));
    }
}
