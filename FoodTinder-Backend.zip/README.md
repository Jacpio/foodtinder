Utwórz bazę danych o nazwie: foodtinder

```console
$ composer install
$ php artisan migrate:fresh
$ php artisan serve
$ php artisan storage:link
```

Jeżeli chcemy zdjęcia: otwórz w powershellu/terminalu

```
$ cd storage/app/public
$ curl.sh
```
